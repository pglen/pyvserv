#!/usr/bin/env python

from datetime import *

today = datetime.now()

print "char *bdate=\"" + datetime.ctime(today) + '";'



