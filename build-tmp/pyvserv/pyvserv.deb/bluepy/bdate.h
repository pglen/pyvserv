char *bdate="Sun Nov 18 13:48:25 2018";
