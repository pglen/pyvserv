#!/bin/bash
find . -name *.pyc -exec rm {}  \;

