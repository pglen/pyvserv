# Libgcrypt
The libgcrypt is the low-level API under gnupg and similar project.

Originally written in C, this package provides - via cffi - an interface
to it for use in python.
