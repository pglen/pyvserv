#/usr/bin/env python

class GcryptException(Exception):
    """
    Generic exception for GCrypt
    """
    pass
